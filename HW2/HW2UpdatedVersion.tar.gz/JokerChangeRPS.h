
#ifndef __H_JOKER_CHANGE_RPS
#define __H_JOKER_CHANGE_RPS

#include "JokerChange.h"

class JokerChangeRPS : public JokerChange {
private:
public:
    // D'tor
    ~JokerChangeRPS(){}
    // Other
    const Point& getJokerChangePosition() const{}
    char getJokerNewRep() const{}
};

#endif // !__H_JOKER_CHANGE_RPS