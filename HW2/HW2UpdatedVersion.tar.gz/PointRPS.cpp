
#include "PointRPS.h"

PointRPS::~PointRPS(){}