
#include "FightInfoRPS.h"

FightInfoRPS::~FightInfoRPS(){}
const Point& FightInfoRPS::getPosition() const{}
char FightInfoRPS::getPiece(int player) const{}
int FightInfoRPS::getWinner() const{}
